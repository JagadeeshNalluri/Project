package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dto.UserDTO;
import com.spring.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/reg.do")
	public ModelAndView registerUser(@RequestParam String userName, @RequestParam String email,
			@RequestParam long mobile,@RequestParam String timeslot) {
		UserDTO userDTO = new UserDTO();
		userDTO.setUserName(userName);
		userDTO.setEmail(email);
		userDTO.setMobile(mobile);
		userDTO.setTimeslot(timeslot);

		boolean register = registrationService.register(userDTO);

		if (register) {
			return new ModelAndView("success.jsp");
		} else {
			return new ModelAndView("failure.jsp");
		}
	}
}
