<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
   echo json_encode(array('status'=>0,'message'=>'Database connection issue'));
} else { 

$sql = "select * from parameters where date < '".date("Y-m-01")."' and date > '".date('Y-m-d', strtotime(date('Y-m-01').' -1 MONTH'))."'";

$result = $conn->query($sql);

	 if($result->num_rows > 0){
		 
	 $currentData = array();
	 $voltageData = array();
	 $frequencyData = array();
	 $powerData = array();
	 $xLabels = array();
		 
		 $i = 0;
	 while($row = $result->fetch_assoc()){
		 $currentData[$i] = $row["current"];
	     $voltageData[$i] = $row["voltage"];
	     $frequencyData[$i] = $row["frequency"];
	     $powerData[$i] = $row["power"];
		 $xLabels[$i] = $row["date"];
		 $i = $i +1;
	 }
	 
	 echo json_encode(array('status'=>1,
	 'current'=>$currentData,
	 'voltage'=>$voltageData,
	 'frequency'=>$frequencyData,
	 'power'=>$powerData,
	 'xLabels'=>$xLabels));
	}else{
		echo json_encode(array('status'=>0,'message'=>'No data'));
	}
	$conn->close();
}

?>