function loadData() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		var jsonObj = JSON.parse(this.responseText);
		if(jsonObj.status == 1){
		document.getElementById("current").innerHTML = jsonObj.current;
		document.getElementById("voltage").innerHTML = jsonObj.voltage;
		document.getElementById("frequency").innerHTML = jsonObj.frequency;
		document.getElementById("power").innerHTML = jsonObj.power;
		}
    }
  };
  xhttp.open("GET", "get_live_data.php", true);
  xhttp.send();
}

	
window.onload = function() {
		document.getElementById("current").innerHTML = 0;
		document.getElementById("voltage").innerHTML = 0;
		document.getElementById("frequency").innerHTML = 0;
		document.getElementById("power").innerHTML = 0;
		loadData();
		setInterval(function(){loadData()}, 30000)
		
		//Line Graph call
		lineGraph();
};


//Graph handling

function lineGraph(){

var randomScalingFactor = function() {
		return Math.ceil(Math.random() * 10.0) * Math.pow(10, Math.ceil(Math.random() * 5));
	};

	var config = {
		type: 'line',
		data: {
			labels: ['01',
		'02',
		'03',
		'04',
		'05',
		'06',
		'07',
		'08',
		'09',
		'10',
		'11',
		'12',
		'13',
		'14',
		'15',
		'16',
		'17',
		'18',
		'19',
		'20',
		'21',
		'22',
		'23',
		'24',
		'25',
		'26',
		'27',
		'28',
		'29',
		'30'],
			datasets: [{
				label: 'Current',
				backgroundColor: window.chartColors.red,
				borderColor: window.chartColors.red,
				fill: false,
				data: [0],
			}, {
				label: 'Voltage',
				backgroundColor: window.chartColors.blue,
				borderColor: window.chartColors.blue,
				fill: false,
				data: [0],
			}, {
				label: 'Frequency',
				backgroundColor: window.chartColors.green,
				borderColor: window.chartColors.green,
				fill: false,
				data: [0],
			}, {
				label: 'Power',
				backgroundColor: window.chartColors.yellow,
				borderColor: window.chartColors.yellow,
				fill: false,
				data: [0],
			}]
		},
		options: {
			responsive: true,
			title: {
				display: true,
				text: 'Graph for previous month data'
			},
			scales: {
				xAxes: [{
					display: true,
				}],
				yAxes: [{
					display: true,
					scaleLabel: {
						display: true,
						labelString: 'probability'
					}
				}]
			}
		}
	};

		var ctx = document.getElementById('canvas').getContext('2d');
		window.myLine = new Chart(ctx, config);
		
		var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
		var jsonObj = JSON.parse(this.responseText);
		if(jsonObj.status == 1){
			config.data.datasets[0].data = jsonObj.current;
			config.data.datasets[1].data = jsonObj.voltage;
			config.data.datasets[2].data = jsonObj.frequency;
			config.data.datasets[3].data = jsonObj.power;
			
			config.data.labels = jsonObj.xLabels;
			
			window.myLine.update();
		}
    }
  };
  xhttp.open("GET", "get_previous_data.php", true);
  xhttp.send();
  
	/*	
	document.getElementById('randomizeData').addEventListener('click', function() {
		config.data.datasets.forEach(function(dataset) {
			dataset.data = dataset.data.map(function() {
				return randomScalingFactor();
			});

		});

		window.myLine.update();
	}); */
	
}