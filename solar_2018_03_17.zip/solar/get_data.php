<?php

if(!isset($_POST["current"]) || !isset($_POST["voltage"]) || !isset($_POST["frequency"]) || !isset($_POST["power"])){
	$response = array('status'=>'fail','message'=>'Please provide all values');
	echo json_encode($response);
	exit;
}

$current = $_POST["current"];
$voltage = $_POST["voltage"];
$frequency = $_POST["frequency"];
$power = $_POST["power"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    $response = array('status'=>'fail','message'=>'Database connection issue.');
	echo json_encode($response);
	exit;
} 

$sql = "insert into parameters(current,voltage,frequency,power,date) value('".$current."','".$voltage."','".$frequency."','".$power."','".date("Y-m-d")."')";

//echo $sql; exit;

if($conn->query($sql) == true){
	$response = array('status'=>'success','message'=>'Data successfuly updated at server');
	}else{
	$response = array('status'=>'fail','message'=>$conn->error);
	}
	echo json_encode($response);
	$conn->close();

?>