<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
   echo json_encode(array('status'=>0,'message'=>'Database connection issue'));
} else { 

$sql = "select * from parameters order by id desc";

$result = $conn->query($sql);

	 if($result->num_rows > 0){
	 $row = $result->fetch_assoc();
	 echo json_encode(array('status'=>1,
	 'current'=>$row["current"],
	 'voltage'=>$row["voltage"],
	 'frequency'=>$row["frequency"],
	 'power'=>$row["power"]));
	}else{
		echo json_encode(array('status'=>0,'message'=>'No data'));
	}
	$conn->close();
}

?>