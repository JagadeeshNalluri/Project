<!doctype html>
<!--[if lt IE 7]>		<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>			<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>			<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>SRMS</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="apple-touch-icon" href="apple-touch-icon.png">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/owl.theme.css">
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/prettyPhoto.css">
	<link rel="stylesheet" href="css/swiper.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="css/transitions.css">
	<link rel="stylesheet" href="css/color.css">
	<link rel="stylesheet" href="css/responsive.css">
	<script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
</head>
<body class="home" >
	<!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
	<div class="preloader-bg">
		<div class="preloader">
			<div class="preloader-top">
				<div class="preloader-top-sun">
					<div class="preloader-top-sun-bg"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-0"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-45"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-90"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-135"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-180"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-225"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-270"></div>
					<div class="preloader-top-sun-line preloader-top-sun-line-315"></div>
				</div>
			</div>
			<div class="preloader-bottom">
				<div class="preloader-bottom-line preloader-bottom-line-lg"></div>
				<div class="preloader-bottom-line preloader-bottom-line-md"></div>
				<div class="preloader-bottom-line preloader-bottom-line-sm"></div>
				<div class="preloader-bottom-line preloader-bottom-line-xs"></div>
			</div>
		</div>
	</div>
	<!--************************************
			Wrapper Start
	*************************************-->
	<div id="wrapper" class="tg-haslayout">
		<!--************************************
				Header Start
		*************************************-->
		<header id="header" class="tg-header tg-haslayout">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
						<strong class="logo">
							<a href="index.html"> <img src="images/ssjcoe.png" alt="image description" style="height:125px;width:125px;"></a>
						</strong>
						<div class="tg-rightarea">
							<nav id="tg-nav" class="tg-nav">
								<div class="navbar-header">
									<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
										<span class="sr-only">Toggle navigation</span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
										<span class="icon-bar"></span>
									</button>
								</div>
								<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
									<ul class="navbar-right">
										<li><a href="index.html">Home</a></li>
											
												<!--<li><a href="index.html">Home1</a></li>
												<li><a href="index2.html">Home2</a></li>
											</ul>
										</li>-->
										<li><a href="aboutus.html">about us</a></li>
										
									<li class="active"><a href="aboutus.html">History</a></li>
									
									
										<!--<li><a href="projects.html">projects</a></li>
										<li> <a href="shop-grid.html">shop</a>
											<ul>
												<li><a href="shop-grid.html">shop grid</a></li>
												<li><a href="shop-detail.html">shop detail</a></li>
											</ul>
										</li>
										<li> <a href="blog-grid.html">blog</a>
											<ul>
											<li><a href="blog-grid.html">blog grid</a></li>
											<li><a href="blog-detail.html">blog detail</a></li>
										</ul>
										</li>
								
										<li>
											<a href="#"><span>pages</span><i class="fa fa-navicon"></i></a>
											<ul>
												<li><a href="team.html">team</a></li>
												<li><a href="contactus.html">contact us</a></li>
												<li><a href="page404.html">404</a></li>
											</ul>
										</li>-->
	
									</ul>
								</div>
							</nav>
							<!--<nav id="tg-addnav" class="tg-addnav tg-search-cart">
								<ul>
									<li class="search-area">
										<div class="tg-search dropdown">
											<a href="#" id="tg-search" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-search"></i></a>
											<div class="dropdown-menu" aria-labelledby="tg-search">
												<form class="form-search">
													<fieldset>
														<input type="search" class="form-control" placeholder="Search">
													</fieldset>
												</form>
											</div>
										</div>
									</li>
									<li class="cart-area">
										<div class="tg-cart dropdown">
											<a href="#" id="tg-cart" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
												<i class="fa fa-shopping-cart"></i>
											</a>
											<div class="dropdown-menu tg-mini-cart" aria-labelledby="tg-cart">
												<ul>
													<li>
														<figure class="tg-product-img">
															<img src="images/thumbs/thumb-01.jpg" alt="image description">
														</figure>
														<div class="tg-product-data">
															<a class="tg-trash fa fa-trash-o" href="#"></a>
															<div class="tg-product-info">
																<h4>2 × Product title</h4>
																<span class="tg-product-price">$ 16.37</span>
																<em class="tg-stock">in stock</em>
															</div>
														</div>
													</li>
													<li>
														<figure class="tg-product-img">
															<img src="images/thumbs/thumb-02.jpg" alt="image description">
														</figure>
														<div class="tg-product-data">
															<a class="tg-trash fa fa-trash-o" href="#"></a>
															<div class="tg-product-info">
																<h4>2 × Product title</h4>
																<span class="tg-product-price">$ 16.37</span>
																<em class="tg-stock">in stock</em>
															</div>
														</div>
													</li>
													<li>
														<figure class="tg-product-img">
															<img src="images/thumbs/thumb-03.jpg" alt="image description">
														</figure>
														<div class="tg-product-data">
															<a class="tg-trash fa fa-trash-o" href="#"></a>
															<div class="tg-product-info">
																<h4>2 × Product title</h4>
																<span class="tg-product-price">$ 16.37</span>
																<em class="tg-stock">in stock</em>
															</div>
														</div>
													</li>
												</ul>
												<div class="tg-cart-total">
													<a class="tg-emptycart pull-left" href="#">
														<i class="tg-trash fa fa-trash-o"></i>
														<em>Clear Your Cart</em>
													</a>
													<strong class="tg-total pull-right">Subtotal: $ 130.49</strong>
												</div>
												<div class="tg-btns shopping">
													<a class="tg-btn" href="#">view cart</a>
													<a class="tg-btn" href="#">checkout</a>
												</div>
											</div>
										</div>
									</li>
								</ul>
							</nav>-->
						</div>
						
					</div>
				</div>
			</div>
		</header>
		<!--************************************
				Header End
		*************************************-->
		<!--************************************
				Banner Start
		*************************************-->
		<div class="tg-main-section tg-banner tg-haslayout parallax-window" data-parallax="scroll" data-bleed="100" data-speed="0.2" data-image-src="images/slider/img-03.jpg">
			<div class="container">
			<ul class="tg-breadcrumb">
				<li>HOME</li>
				<li>VIEW REPORT</li>
			</ul>
			</div>
		</div>
		<!--************************************
				Banner End
		*************************************-->
	<main id="main" class="tg-haslayout">
	 <section class="tg-main-section tg-haslayout">
      <div class="container">
	  
	  <h3>Data for current month</h3>
	  
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    echo '<b>Database connection issue.</b>';
} else { 

$sql = "select * from parameters where date > '".date("Y-m-01")."'";

$result = $conn->query($sql);

	 if($result->num_rows > 0){
	 
	 echo '<table class="table table-hover">';

 		 echo '<tr>';
		 
		 echo '<th>Id</th>';
		 echo '<th>Current</th>';
		 echo '<th>Voltage</th>';
		 echo '<th>Frequency</th>';
		 echo '<th>Power</th>';
		 
		 echo '</tr>';

	 $i = 1;
	 
	 while($row = $result->fetch_assoc()){
		 echo '<tr>';
		 
		 echo '<td>'.$i.'</td>';
		 echo '<td>'.$row["current"].'</td>';
		 echo '<td>'.$row["voltage"].'</td>';
		 echo '<td>'.$row["frequency"].'</td>';
		 echo '<td>'.$row["power"].'</td>';
		 
		 echo '</tr>';
		 
		 $i++;
	 }

	 echo '</table>';
	 
	}else{
	echo '<b>No records found.</b>';
	}
	$conn->close();
}

?>
</div>
</section>
</main>
<!--************************************
			Footer Start
	*************************************-->
  <footer id="footer" class="tg-haslayout">
    <!--<div class="four-columns haslayout">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-6 width-footercol">
            <div class="col aboutus"> <strong class="logo"> <a href="index.html"><img src="images/logo2.png" alt="image description"></a> </strong>
              <div class="tg-description">
                <p>Consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolorin.</p>
              </div>
              <ul class="tg-socialicon">
                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-6 width-footercol">
            <div class="col tg-recent-post">
              <div class="tg-heading-border">
                <h3>Recent Posts</h3>
              </div>
              <ul>
                <li> <a href="#">
                  <p>Corem ipsum dolor sit amet</p>
                  <p>04 February 2015</p>
                  </a> </li>
                <li> <a href="#">
                  <p>Mirum est notare quam littera gothica</p>
                  <p>04 February 2015</p>
                  </a> </li>
                <li> <a href="#">
                  <p>Duis autem vel eum iriure</p>
                  <p>04 February 2015</p>
                  </a> </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-6 width-footercol">
            <div class="col tg-tags">
              <div class="tg-heading-border">
                <h3>Popular Tags</h3>
              </div>
              <ul>
                <li><a href="#">Clean eco</a></li>
                <li><a href="#">eco</a></li>
                <li><a href="#">green</a></li>
                <li><a href="#">solar</a></li>
                <li><a href="#">windmill</a></li>
                <li><a href="#">air</a></li>
                <li><a href="#">green house</a></li>
                <li><a href="#">sun</a></li>
                <li><a href="#">solar fuel</a></li>
                <li><a href="#">eco</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6 col-xs-6 width-footercol">
            <div class="col tg-flicker">
              <div class="tg-heading-border">
                <h3>Flickr Stream</h3>
              </div>
              <ul>
                <li> <a href="images/thumbs/thumb-04.jpg" data-rel="prettyPhoto[flickr]"><img src="images/thumbs/thumb-04.jpg" alt="image description"></a> </li>
                <li> <a href="images/thumbs/thumb-05.jpg" data-rel="prettyPhoto[flickr]"><img src="images/thumbs/thumb-05.jpg" alt="image description"></a> </li>
                <li> <a href="images/thumbs/thumb-06.jpg" data-rel="prettyPhoto[flickr]"><img src="images/thumbs/thumb-06.jpg" alt="image description"></a> </li>
                <li> <a href="images/thumbs/thumb-07.jpg" data-rel="prettyPhoto[flickr]"><img src="images/thumbs/thumb-07.jpg" alt="image description"></a> </li>
                <li> <a href="images/thumbs/thumb-08.jpg" data-rel="prettyPhoto[flickr]"><img src="images/thumbs/thumb-08.jpg" alt="image description"></a> </li>
                <li> <a href="images/thumbs/thumb-09.jpg" data-rel="prettyPhoto[flickr]"><img src="images/thumbs/thumb-09.jpg" alt="image description"></a> </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>-->
    <div class="bottom-bar haslayout">
      <div class="container">
        <div class="copyright">
          <p>Copyright 2016 &copy; <a href ="http://freecssthemes.com/" target="_blank" title="Click to get this template!"/>SRMS</a> | All Rights Reserved</p>
        </div>
      </div>
    </div>
  </footer>
	<!--************************************
			Footer End
	*************************************-->
</div>
	<!--************************************
			Wrapper End
	*************************************-->
	<!--************************************
			Calculator Start
	*************************************-->
	<!--<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="topcalculator">
					<span class="box1">Qty</span>
					<span class="box2">Appliances</span>
					<span class="box3">Usage <strong>(Hour)</strong></span>
					<span class="box4">Rating <strong>(Watt)</strong></span>
					<span class="box5">Energy <strong>(Watt/Hour)</strong></span>
				</div>
				<div id="calculator-area" class="calculator-table">
					<ul>
						<li>
							<span class="box1"><input type="text"></span>
							<span class="box2">
								<select>
									<option>LED / LCD</option>
									<option>Computer</option>
									<option>Fridge</option>
									<option>Lamp</option>
									<option>Other</option>
								</select></span>
							<span class="box3"><input type="text"></span>
							<span class="box4"><input type="text"></span>
							<span class="box5"><input type="text"></span>
							<a href="#" class="tg-btnremove"><i class="fa fa-times"></i></a>
						</li>
						<li>
							<span class="box1"><input type="text" ></span>
							<span class="box2">
								<select>
									<option>LED / LCD</option>
									<option>Computer</option>
									<option>Fridge</option>
									<option>Lamp</option>
									<option>Other</option>
								</select></span>
							<span class="box3"><input type="text"></span>
							<span class="box4"><input type="text"></span>
							<span class="box5"><input type="text"></span>
							<a href="#" class="tg-btnremove"><i class="fa fa-times"></i></a>
						</li>
						<li>
							<span class="box1"><input type="text"></span>
							<span class="box2">
								<select>
									<option>LED / LCD</option>
									<option>Computer</option>
									<option>Fridge</option>
									<option>Lamp</option>
									<option>Other</option>
								</select></span>
							<span class="box3"><input type="text"></span>
							<span class="box4"><input type="text"></span>
							<span class="box5"><input type="text"></span>
							<a href="#" class="tg-btnremove"><i class="fa fa-times"></i></a>
						</li>
					</ul>
					<div class="footer-calculator tg-haslayout">
						<div class="total-area pull-right">
							<label for="cal-total">total Consumption:</label>
							<input type="text" id="cal-total">
							<div class="tg-calculator-btns tg-haslayout">
								<a href="#" id="tg-btnreset" class="tg-btn reset">RESET</a>
								<a href="#" id="tg-addrows" class="tg-btn add-row">ADD ROW</a>
							</div>
						</div>
					</div>
					<div class="tg-suggested-products tg-haslayout">
						<div class="row">
							<h2>Suggested Systems</h2>
							<div id="tg-scrolling" class="tg-scrolling">
								<div class="tg-products-detail">
									<figure>
										<img src="images/products/img-01.jpg" alt="image description">
										<div class="tg-img-hover">
											<div class="tg-displaytable">
												<div class="tg-displaytablecell">
													<a href="#"><i class="fa fa-search"></i></a>
												</div>
											</div>
										</div>
									</figure>
									<div class="product-description tg-haslayout">
										<ul>
											<li><span>Name:</span><a href="#"> Waterproof Solar Panel</a></li>
											<li><span>Type:</span> Dolor amet</li>
											<li><span>Capacity:</span> 1KV, 2KV, 3KV</li>
											<li><span>Backup:</span> 5 Hours</li>
											<li><span>Material:</span> Stainless Steel</li>
											<li><span>Wire:</span> Coper</li>
											<li><span>Waterproof:</span> YES</li>
										</ul>
									</div>
								</div>
								<div class="tg-products-detail">
									<figure>
										<img src="images/products/img-02.jpg" alt="image description">
										<div class="tg-img-hover">
											<div class="tg-displaytable">
												<div class="tg-displaytablecell">
													<a href="#"><i class="fa fa-search"></i></a>
												</div>
											</div>
										</div>
									</figure>
									<div class="product-description tg-haslayout">
										<ul>
											<li><span>Name:</span><a href="#"> Waterproof Solar Panel</a></li>
											<li><span>Type:</span> Dolor amet</li>
											<li><span>Capacity:</span> 1KV, 2KV, 3KV</li>
											<li><span>Backup:</span> 5 Hours</li>
											<li><span>Material:</span> Stainless Steel</li>
											<li><span>Wire:</span> Coper</li>
											<li><span>Waterproof:</span> YES</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--************************************
			Calculator End
	*************************************-->
	<script src="js/vendor/jquery-pulgin.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/prettyPhoto.js"></script>
	<script src="js/isotope.pkgd.js"></script>
	<script src="js/hoverdir.js"></script>
	<script src="js/owl.carousel.js"></script>
	<script src="js/parallax.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/appear.js"></script>
	<script src="js/countTo.js"></script>
	<script src="js/swiper.min.js"></script>
	<script src="js/nicescroll.js"></script>
	<script src="js/handlebars.min.js"></script>
	<script src="js/gmap3.js"></script>
	<script src="js/main.js"></script>
</body>
</html>