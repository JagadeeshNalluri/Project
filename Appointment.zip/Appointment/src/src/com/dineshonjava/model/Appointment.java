package src.com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

 
@Entity
@Table(name="appointment")
public class Appointment implements Serializable{

	//private static final long serialVersionUID = -723583058586873479L;
	
//	@Id
//	//@GeneratedValue(strategy=GenerationType.AUTO)
//	@Column(name = "empid")
//	private Integer empId;
//	
	@Column(name="name")
	private String Name;
	
	@Column(name="email")
	private String Email;
	
	@Column(name="phone")
	private Long Phone;
	
	@Column(name="timeslot")
	private String Timeslot;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public Long getPhone() {
		return Phone;
	}

	public void setPhone(Long phone) {
		Phone = phone;
	}

	public String getTimeslot() {
		return Timeslot;
	}

	public void setTimeslot(String timeslot) {
		Timeslot = timeslot;
	}

	

}
