package src.com.dineshonjava.dao;

import java.util.List;

import src.com.dineshonjava.model.Appointment;

 
public interface AppointmentDao {
	
	public void addAppointment(Appointment appointment);

	public List<Appointment> listAppointments();
	
	public Appointment getAppointment(String name);
	
	public void deleteAppointment(Appointment appointment);
}
