package src.com.dineshonjava.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import src.com.dineshonjava.model.Appointment;

 
@Repository("appointmentDao")
public class AppointmentDaoImpl implements AppointmentDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addAppointment(Appointment appointment) {
		sessionFactory.getCurrentSession().saveOrUpdate(appointment);
	}

	@SuppressWarnings("unchecked")
	public List<Appointment> listAppointments() {
		return (List<Appointment>) sessionFactory.getCurrentSession().createCriteria(Appointment.class).list();
	}

	public Appointment getAppointment(String name) {
		return (Appointment) sessionFactory.getCurrentSession().get(Appointment.class, name);
	}

	public void deleteAppointment(Appointment appointment) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM appointment WHERE name = "+appointment.getName()).executeUpdate();
	}

}