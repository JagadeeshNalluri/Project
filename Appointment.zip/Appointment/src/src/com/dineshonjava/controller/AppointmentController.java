package src.com.dineshonjava.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import src.com.dineshonjava.bean.AppointmentBean;
import src.com.dineshonjava.model.Appointment;
import src.com.dineshonjava.service.AppointmentService;

@Controller
public class AppointmentController {

	@Autowired
	private AppointmentService appointmentService;

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveAppointment(@ModelAttribute("command") AppointmentBean appointmentBean, BindingResult result) {
		Appointment appointment = prepareModel(appointmentBean);
		appointmentService.addAppointment(appointment);
		return new ModelAndView("redirect:/add.html");
	}

	@RequestMapping(value = "/appointments", method = RequestMethod.GET)
	public ModelAndView listAppointments() {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("appointments", prepareListofBean(appointmentService.listAppointments()));
		return new ModelAndView("appointmentsList", model);
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addAppointment(@ModelAttribute("command") AppointmentBean appointmentBean, BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("appointments", prepareListofBean(appointmentService.listAppointments()));
		return new ModelAndView("addAppointment", model);
	}

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView editAppointment(@ModelAttribute("command") AppointmentBean appointmentBean, BindingResult result) {
		appointmentService.deleteAppointment(prepareModel(appointmentBean));
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("appointment", null);
		model.put("appointments", prepareListofBean(Appointment.listAppointments()));
		return new ModelAndView("addAppointment", model);
	}

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView deleteAppointment(@ModelAttribute("command") AppointmentBean appointmentBean, BindingResult result) {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("appointment",prepareAppointmentBean(Appointment.getAppointment(appointmentBean.getName())));
		model.put("appointments", prepareListofBean(Appointment.listAppointments()));
		return new ModelAndView("addAppointment", model);
	}

	private Appointment prepareModel(AppointmentBean appointmentBean) {
		Appointment appointment = new Appointment();
		appointment.setName(appointmentBean.getName());
		appointment.setEmail(appointmentBean.getEmail());
		appointment.setPhone(appointmentBean.getPhone());
		appointment.setTimeslot(appointmentBean.getTimeslot());
//		appointmentBean.setId(null);
		return appointment;
	}

	private List<AppointmentBean> prepareListofBean(List<Appointment> appointments) {
		List<AppointmentBean> beans = null;
		if (appointments != null && !appointments.isEmpty()) {
			beans = new ArrayList<AppointmentBean>();
			AppointmentBean bean = null;
			for (Appointment appointment : appointments) {
				bean = new AppointmentBean();
				bean.setName(appointment.getName());
				bean.setEmail(appointment.getEmail());
				bean.setPhone(appointment.getPhone());
				bean.setTimeslot(appointment.getTimeslot());
				beans.add(bean);
			}
		}
		return beans;
	}

	private AppointmentBean prepareAppointmentBean(Appointment appointment) {
		AppointmentBean bean = new AppointmentBean();
		bean.setTimeslot(appointment.getTimeslot());
		bean.setPhone(appointment.getPhone());
		bean.setEmail(appointment.getEmail());
		bean.setName(appointment.getName());
		return bean;
	}
}
