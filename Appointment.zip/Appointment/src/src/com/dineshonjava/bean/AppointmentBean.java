package src.com.dineshonjava.bean;

 //create table employee(empid number,empname varchar2(30),empage number,salary number,
//empaddress varchar2(30));
public class AppointmentBean {
	private String name,email,timeslot;
	private Long phone;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTimeslot() {
		return timeslot;
	}
	public void setTimeslot(String timeslot) {
		this.timeslot = timeslot;
	}
	public Long getPhone() {
		return phone;
	}
	public void setPhone(Long phone) {
		this.phone = phone;
	}
	
}
