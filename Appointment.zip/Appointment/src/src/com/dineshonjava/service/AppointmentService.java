package src.com.dineshonjava.service;

import java.util.List;

import src.com.dineshonjava.model.Appointment;

 
public interface AppointmentService {
	
	public void addAppointment(Appointment appointment);

	public List<Appointment> listAppointments();
	
	public Appointment getAppointment(String name);
	
	public void deleteAppointment(Appointment appointment);
}
