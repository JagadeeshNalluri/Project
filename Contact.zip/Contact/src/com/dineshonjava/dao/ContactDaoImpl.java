package com.dineshonjava.dao;


import java.util.List;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.dineshonjava.model.Contact;


 
@Repository("contactDao")
public class ContactDaoImpl implements ContactDao {


    @Autowired
    private SessionFactory sessionFactory;
    
    public void addContact(Contact contact) {
        sessionFactory.getCurrentSession().saveOrUpdate(contact);
    }


    @SuppressWarnings("unchecked")
    public List<Contact> listPropertiess() {
        return (List<Contact>) sessionFactory.getCurrentSession().createCriteria(Contact.class).list();
    }


    public Contact getContact(int id) {
        return (Contact) sessionFactory.getCurrentSession().get(Contact.class, id);
    }


    public void deleteContact(Contact contact) {
        sessionFactory.getCurrentSession().createQuery("DELETE FROM Contact WHERE id = "+contact.getId()).executeUpdate();
    }


}
 











