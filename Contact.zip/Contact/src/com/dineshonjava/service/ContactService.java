package com.dineshonjava.service;


import java.util.List;


import com.dineshonjava.model.Contact;


 
public interface ContactService {
    
    public void addContact(Contact contact);


    public List<Contact> listContactss();
    
    public Contact getContact(int id);
    
    public void deleteContact(Contact contact);
}
 






